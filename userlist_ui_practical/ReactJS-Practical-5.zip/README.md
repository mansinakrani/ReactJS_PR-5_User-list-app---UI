# Practical-5 :  USer list - UI

## Getting Started

Clone this repo and install dependencies with

```bash
  npm install
```

## Starting The Dev Server

To start the server and start hacking, run

```bash
npm start
```

## Demo
[Link]()
[Image](https://github.com/mansinakrani/ReactJS_PR-5_User-list-app---UI/blob/6d6c2796ae9574a3a7ba18194a6d2eda47acc9da/userlist_ui_practical/ReactJS_Practical-5_Demo.png)

## Repo Link
[Practical - 5](https://github.com/mansinakrani/ReactJS_PR-5_User-list-app---UI.git)

## PR Link
[Pull-Request](https://github.com/mansinakrani/ReactJS_PR-5_User-list-app---UI/pull/1#issue-1158126177) 